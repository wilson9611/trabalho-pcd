package br.ufrn.imd.lojaRapida.dao;


import javax.ejb.Stateless;

/**
 * Session Bean implementation class TesteEJB
 */
@Stateless(mappedName = "testeEJB")
public class TesteEJB implements TesteEJBRemote, TesteEJBLocal {

    /**
     * Default constructor. 
     */
    public TesteEJB() {
        // TODO Auto-generated constructor stub
    }

}
