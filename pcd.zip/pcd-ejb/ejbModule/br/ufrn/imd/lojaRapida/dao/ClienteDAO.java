package br.ufrn.imd.lojaRapida.dao;

import java.util.List;

import javax.ejb.Stateless;

import br.ufrn.imd.lojaRapida.dominio.Cliente;

@Stateless
public class ClienteDAO extends GenericDAO<Cliente>{

	@Override
	public Class<Cliente> getClassType() {
		// TODO Auto-generated method stub
		return Cliente.class;
	}
	
	public List<Cliente> buscaCliente(Cliente cliente) {
		 List<Cliente> listaCliente = findAll();
		 return listaCliente;
		 
	}
	
}
