package br.ufrn.imd.lojaRapida.controle;

import java.util.List;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;

import org.primefaces.component.tabview.TabView;

import br.ufrn.imd.lojaRapida.dao.CategoriaDAO;
import br.ufrn.imd.lojaRapida.dao.ProdutoDAO;
import br.ufrn.imd.lojaRapida.dominio.Produto;
import br.ufrn.imd.lojaRapida.util.MensagemUTIL;

@ManagedBean(name="produtoMBean")
public class ProdutoMBean {

	private TabView tabView;
	
	@EJB
	private ProdutoDAO dao;
	
	@EJB
	private CategoriaDAO catDao;
	
	private Produto produto = new Produto();
	
	public List<Produto> getListaCompleta(){
		try{
			return dao.findAll();
		}finally{
			dao.close();
		}	
	}
	
	public String selecionar(Produto produto){
		this.produto = produto;
		return "/admin/produto";
	}
	
	public String salvar(){
		try{
			//persiste  o produto no banco de dados
			if(produto.getId() > 0){
				dao.update(produto);
			}else{
				dao.create(produto);
			}
			
			//recarrega as informacoes da categoria
			produto.setCategoria( catDao.findByPrimaryKey(
									Integer.valueOf( produto.getCategoria().getId() )));
			
			//mensagem de sucesso
			MensagemUTIL.addInfo("Produto Salvo com Sucesso.");
			
			//reiniciando o objeto
			produto = new Produto();
		}finally{
			dao.close();
			catDao.close();
		}
		return null;
	}
	
	
	public String deletar(Produto produto){
		

		try{
			dao.delete(produto);

			MensagemUTIL.addInfo("Registro deletado com sucesso");
		}finally{
			dao.close();  
		}
		
		return null;
	}
	
	
	public String deletaraAjax(Produto produto){

		try{
			dao.delete(produto);
			MensagemUTIL.addInfo("Registro deletado com sucesso");
		}finally{
			dao.close();  
		}
		return null;
	}
	

	

	public Produto getProduto() {
		return produto;
	}

	public void setProduto(Produto produto) {
		this.produto = produto;
	}

	public TabView getTabView() {
		return this.tabView;
	}

	public void setTabView(TabView tabView) {
		this.tabView = tabView;
	}


	
}
