package br.ufrn.imd.lojaRapida.controle;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletResponse;

import br.ufrn.imd.lojaRapida.dominio.Aluno;

@ManagedBean
public class SobreMBean {
	HttpServletResponse response;
	private String sobreTexto="Esta loja foi desenvolvida como estudo de caso durante a disciplina WEB.";
	public SobreMBean() {

	}
	
	public String redireciona() {
		try {


			FacesContext.getCurrentInstance().getExternalContext().redirect("sobre_loja.xhtml");


			//response.sendRedirect("sobre_loja.xhtml");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public String getSobreTexto() {
		return sobreTexto;
	}
	public void setSobreTexto(String sobreTexto) {
		this.sobreTexto = sobreTexto;
	}
	
	public List<Aluno> getObterListaAlunos() {
		List<Aluno> alunos = new ArrayList<Aluno>();
		Aluno aluno1 = new Aluno();
		
		aluno1.setDataNascimento("28/02/1971");
		aluno1.setNome("Wilson");
		aluno1.setEndereco("Endereco de wilson");
		alunos.add(aluno1);
		
		Aluno aluno2 = new Aluno();
		aluno2.setDataNascimento("28/02/1971");
		aluno2.setNome("Wilson 2");
		aluno2.setEndereco("Endereco de wilson 2");
		alunos.add(aluno2);
		
		
		return alunos;
	}
	
}
