package br.ufrn.imd.lojaRapida.controle;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;

import org.primefaces.component.tabview.TabView;

import br.ufrn.imd.lojaRapida.dao.ClienteDAO;
import br.ufrn.imd.lojaRapida.dominio.Cliente;
import br.ufrn.imd.lojaRapida.util.MensagemUTIL;

@ManagedBean(name="clienteMBean")
public class ClienteMBean {
	
	private TabView tabView;
	
	Cliente cliente;
	@EJB
	ClienteDAO dao;
	
	@PostConstruct
	public void init() {
		this.cliente = new Cliente();
	}
//	@PreDestroy
//	public void destroy() {
//		dao.close();
//	}
	
	public List<Cliente> getListaCompleta(){
	

		try{
			return dao.findAll();
		}finally{
			dao.close();
		}
	}

	public String selectionar(Cliente cliente) {
		this.cliente = cliente;
		return "/admin/cliente";
	}
	
	public String salvar() {
		if (!cliente.getSenha().equals(cliente.getSenhaConfirmacao())) {
			//MensagemUTIL.addInfo("Confirma��o da Senha n�o � igual a senha informada.");
			MensagemUTIL.addError("Confirma��o da Senha n�o � igual a senha informada.");
			return null;
		}
		
		if (cliente.getId()>0) {
			dao.update(cliente);
		} else {
			dao.create(cliente);
		}
		MensagemUTIL.addInfo("Cliente cadastrado com sucesso!!!");
		cliente = new Cliente();
		return null;
	}
	
	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	public TabView getTabView() {
		return this.tabView;
	}

	public void setTabView(TabView tabView) {
		this.tabView = tabView;
	}
	
	
}
