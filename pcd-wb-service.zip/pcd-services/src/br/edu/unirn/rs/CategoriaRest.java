package br.edu.unirn.rs;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;


import br.ufrn.imd.lojaRapida.dao.CategoriaDAO;
import br.ufrn.imd.lojaRapida.dominio.Categoria;

@Stateless
@Path("/categoria")
@Produces({MediaType.APPLICATION_JSON})
public class CategoriaRest {
	
	@EJB
	CategoriaDAO dao;
	
	@GET
	public List<Categoria> getAll() {
		return dao.findAll();
	}
	
	@GET
	@Path("{id}")	
	public Response get(@PathParam("id") int id){
		Categoria categoria = dao.findByPrimaryKey(id);
		if(categoria==null){
			return Response.status(404).build();
		}
		return Response.status(200).entity(categoria).build();
	}
	
	
	@POST
	public void salvar(Categoria categoria) {
		if (categoria.getId()==0) {
			dao.create(categoria);
		} else {
			dao.update(categoria);
		}
	}
	
	@PUT
	@Path("{id}")
	public Categoria alterar(@PathParam("id") int id,Categoria categoria){
		Categoria cat = dao.findByPrimaryKey(id);
		if (cat!=null) {
			cat = categoria;
			dao.update(cat);
		}
		return cat;
	}
	
	@DELETE
	@Path("{id}")
	public Response remover(@PathParam("id") int id){
		Categoria cat = dao.findByPrimaryKey(id);
		if (cat!=null) {
			dao.delete(cat);
			return Response.status(200).entity(cat).build();
		}
		return Response.status(404).build();
			
	}
}
