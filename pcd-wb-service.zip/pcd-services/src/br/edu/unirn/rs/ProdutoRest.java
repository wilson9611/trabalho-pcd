package br.edu.unirn.rs;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import br.ufrn.imd.lojaRapida.dao.CategoriaDAO;
import br.ufrn.imd.lojaRapida.dao.ProdutoDAO;
import br.ufrn.imd.lojaRapida.dominio.Categoria;
import br.ufrn.imd.lojaRapida.dominio.Produto;

@Stateless
@Path("/produto")
@Produces({MediaType.APPLICATION_JSON})
public class ProdutoRest {

	@EJB
	ProdutoDAO dao;
	
	@GET
	public List<Produto> getAll(){
		return dao.findAll();
	}
	
	@POST
	public void salvar(Produto produto) {
		if (produto.getId()==0) {
			dao.create(produto); 
		} else {
			dao.update(produto);
		}
	}
	
	@PUT
	@Path("{id}")
	public Produto alterar(@PathParam("id") int id,Produto produto){
		Produto p = dao.findByPrimaryKey(id);
		if (p!=null) {
			p = produto;
			dao.update(p);
		}
		return p;
	}
	
	@DELETE
	@Path("{id}")
	public Response remover(@PathParam("id") int id){
		Produto p = dao.findByPrimaryKey(id);
		if (p!=null) {
			dao.delete(p);
			return Response.status(200).entity(p).build();
		}
		return Response.status(404).build();
			
	}
}
