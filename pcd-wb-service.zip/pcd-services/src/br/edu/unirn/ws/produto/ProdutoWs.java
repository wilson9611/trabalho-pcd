package br.edu.unirn.ws.produto;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import br.ufrn.imd.lojaRapida.dominio.Produto;

@WebService
public interface ProdutoWs {
	
	@WebMethod
	public void salvar(Produto proudto);
	
	@WebMethod
	public void deletar(Produto produto);
	
	@WebMethod
	public List<Produto> listar();

}
