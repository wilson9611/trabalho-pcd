package br.edu.unirn.ws.produto.impl;


import java.util.List;

import javax.ejb.EJB;
import javax.jws.WebService;

import org.jboss.logging.Logger;

import br.edu.unirn.ws.produto.ProdutoWs;
import br.ufrn.imd.lojaRapida.dao.ProdutoDAO;
import br.ufrn.imd.lojaRapida.dominio.Produto;

@WebService(serviceName="ProdutoService")
public class ProdutoWsImpl implements ProdutoWs{

	private static Logger log = Logger.getLogger(Produto.class);
	
	@EJB
	ProdutoDAO dao;
	
	@Override
	public void salvar(Produto produto) {
		if (produto !=null && produto.getId()==0) {
			dao.create(produto);
		}
		else {
			dao.update(produto);
		}
	}

	@Override
	public void deletar(Produto produto) {
		// TODO Auto-generated method stub
		dao.delete(produto);
		
	}

	@Override
	public List<Produto> listar() {
		// TODO Auto-generated method stub
		List<Produto> lista = dao.findAll();
		return lista;
	}

}
