package br.edu.unirn.ws.categoria.impl;

import java.util.List;

import javax.ejb.EJB;
import javax.jws.WebService;

import org.jboss.logging.Logger;

import br.edu.unirn.ws.categoria.CategoriaWs;
import br.ufrn.imd.lojaRapida.dao.CategoriaDAO;
import br.ufrn.imd.lojaRapida.dominio.Categoria;

/**
 * @author wilson
 *
 */
@WebService(serviceName = "CategoriaService")
public class CategoriaWsImpl implements CategoriaWs{

	private Logger log = Logger.getLogger(CategoriaWsImpl.class);
	
	@EJB 
	private CategoriaDAO dao;
	

	@Override
	public void Salvar(Categoria categoria) {
		// TODO Auto-generated method stub
		try{
			if (categoria.getId()==0 ){
				dao.create(categoria);
			}else{
				dao.update(categoria);
			}
		}finally{
			dao.close();  
		}
	}
	

	@Override
	public List<Categoria> listar() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}


	@Override
	public void deletar(Categoria categoria) {
		// TODO Auto-generated method stub
		dao.delete(categoria);
	}


}
