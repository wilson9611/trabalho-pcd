package br.edu.unirn.ws.categoria;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import br.ufrn.imd.lojaRapida.dominio.Categoria;

@WebService
public interface CategoriaWs {
	
	@WebMethod 
	public void Salvar(Categoria categoria);
	
	@WebMethod
	public void deletar(Categoria categoria);
	
	@WebMethod
	public List<Categoria> listar();
	
}
