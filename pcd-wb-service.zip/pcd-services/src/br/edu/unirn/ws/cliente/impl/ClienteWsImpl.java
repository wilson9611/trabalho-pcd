package br.edu.unirn.ws.cliente.impl;

import java.util.List;

import javax.ejb.EJB;
import javax.jws.WebService;

import org.jboss.logging.Logger;

import br.edu.unirn.ws.cliente.ClienteWs;
import br.ufrn.imd.lojaRapida.dao.ClienteDAO;
import br.ufrn.imd.lojaRapida.dominio.Cliente;

@WebService(serviceName="ClienteService")
public class ClienteWsImpl implements ClienteWs {

	private Logger log = Logger.getLogger(Cliente.class);
	
	@EJB
	private ClienteDAO dao;
	
	@Override
	public void salvar(Cliente cliente) {
		// TODO Auto-generated method stub
		if (cliente!=null && cliente.getId()==0) {
			dao.create(cliente);
		} else {
			dao.update(cliente);
		}
		
	}

	@Override
	public void deletar(Cliente cliente) {
		// TODO Auto-generated method stub
		dao.delete(cliente);
		
	}

	@Override
	public List<Cliente> listar() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

}
