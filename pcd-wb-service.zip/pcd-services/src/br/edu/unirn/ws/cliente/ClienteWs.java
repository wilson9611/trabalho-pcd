package br.edu.unirn.ws.cliente;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import br.ufrn.imd.lojaRapida.dominio.Cliente;

@WebService
public interface ClienteWs {

	@WebMethod
	public void salvar(Cliente cliente);
	
	@WebMethod
	public void deletar(Cliente cliente);
	
	@WebMethod
	public List<Cliente> listar();
}
