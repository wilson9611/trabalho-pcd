/**
 * 
 */
/**
 * @author wilson
 *
 */
package br.edu.unirn.ws.cliente.impl;