package br.ufrn.imd.lojaRapida.dao;

import javax.ejb.Remote;

@Remote
public interface TesteEJBRemote {

}
