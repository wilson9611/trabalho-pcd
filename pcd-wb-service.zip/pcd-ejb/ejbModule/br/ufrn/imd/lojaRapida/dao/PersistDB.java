package br.ufrn.imd.lojaRapida.dao;

public interface PersistDB {

	public int getId();
	
	public void setId(int id);
}

