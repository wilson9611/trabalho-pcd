package br.ufrn.imd.lojaRapida.dao;

import javax.ejb.Local;

@Local
public interface TesteEJBLocal {

}
