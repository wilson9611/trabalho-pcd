package br.ufrn.imd.lojaRapida.dao;

import br.ufrn.imd.lojaRapida.dominio.Oferta;


public class OfertaDAO extends GenericDAO<Oferta>{

	@Override
	public Class<Oferta> getClassType() {
		// TODO Auto-generated method stub
		return Oferta.class;
	}

}
