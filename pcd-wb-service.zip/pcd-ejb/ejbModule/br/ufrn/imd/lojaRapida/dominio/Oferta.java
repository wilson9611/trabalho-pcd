package br.ufrn.imd.lojaRapida.dominio;

import java.io.Serializable;
import java.util.Calendar;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import br.ufrn.imd.lojaRapida.dao.PersistDB;

@Entity
public class Oferta implements PersistDB, Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1973558022820047609L;

	@Id
	@GeneratedValue
	private int id;
	
	//private Produto produto;
	
	private double preco;
	private Calendar DataFim;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
//	public Produto getProduto() {
//		return produto;
//	}
//	public void setProduto(Produto produto) {
//		this.produto = produto;
//	}
	public double getPreco() {
		return preco;
	}
	public void setPreco(double preco) {
		this.preco = preco;
	}
	public Calendar getDataFim() {
		return DataFim;
	}
	public void setDataFim(Calendar dataFim) {
		DataFim = dataFim;
	}
	
	
}
