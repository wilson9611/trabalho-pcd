package br.ufrn.imd.lojaRapida.negocio;

import br.ufrn.imd.lojaRapida.dao.PersistDB;

public interface IService {
	
	public void executar(PersistDB obj);
}
