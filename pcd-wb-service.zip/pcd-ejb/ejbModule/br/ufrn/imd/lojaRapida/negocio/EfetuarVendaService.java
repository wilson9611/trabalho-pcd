package br.ufrn.imd.lojaRapida.negocio;

import br.ufrn.imd.lojaRapida.dao.PersistDB;

public class EfetuarVendaService implements IService {

	@Override
	public void executar(PersistDB obj) {
		// TODO Auto-generated method stub
	}



}
