package br.ufrn.imd.lojaRapida.controle;

import java.util.List;

import javax.faces.bean.ManagedBean;

import br.ufrn.imd.lojaRapida.dao.OfertaDAO;
import br.ufrn.imd.lojaRapida.dominio.Oferta;
import br.ufrn.imd.lojaRapida.util.MensagemUTIL;

@ManagedBean
public class OfertaMBean {

	private Oferta oferta;
	
	public List<Oferta> getListaCompleta(){
		OfertaDAO dao = new OfertaDAO();
		try{
			return dao.findAll();
		}finally{
			dao.close();
		}	
	}
	
	public String selecionar(Oferta oferta){
		this.oferta = oferta;
		return "/admin/produto";
	}
	
	public String salvar(){
		OfertaDAO dao = new OfertaDAO();
		try{
			//persiste  o produto no banco de dados
			if(oferta.getId() > 0){
				dao.update(oferta);
			}else{
				dao.create(oferta);
			}
			

			
			//mensagem de sucesso
			MensagemUTIL.addInfo("Oferta Salva com Sucesso.");
			
			//reiniciando o objeto
			oferta = new Oferta();
		}finally{
			dao.close();
		}
		return null;
	}

	public Oferta getOferta() {
		return oferta;
	}

	public void setOferta(Oferta oferta) {
		this.oferta = oferta;
	}
	
}
