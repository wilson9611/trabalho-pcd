package br.ufrn.imd.lojaRapida.controle;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.application.FacesMessage.Severity;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

//import org.hibernate.service.spi.InjectService;
import org.primefaces.component.tabview.Tab;

import br.ufrn.imd.lojaRapida.dao.CategoriaDAO;
import br.ufrn.imd.lojaRapida.dao.PersistDB;
import br.ufrn.imd.lojaRapida.dominio.Categoria;
import br.ufrn.imd.lojaRapida.util.MensagemUTIL;

/**
 * Controla as opera��es relacionadas a categorias
 * @author Usuario
 *
 */

@ManagedBean
public class CategoriaMBean{
	
	@EJB 
	private CategoriaDAO dao;
	
	private Categoria categoria;
	
	private Tab tabCadastro;
	

	@PostConstruct
	public void init() {
		this.categoria = new Categoria();
	}
	/**
	 * Retorna a listagem todos os registros do banco
	 * @return
	 */
	public List<Categoria> getListaCompleta(){
		
		//CategoriaDAO dao = new CategoriaDAO();
		
		try{
			return dao.findAll();
		}finally{
			dao.close();
		}
	}
	
	
	/**
	 * M�todo que salva o objeto
	 * @return
	 */
	public String salvar(){
		

		try{
			if (categoria.getId()==0 ){
				dao.create(categoria);
				categoria  = new Categoria();
			}else{
				dao.update(categoria);
			}
			MensagemUTIL.addInfo("Categoria salva com sucesso");
		}finally{
			dao.close();  
		}
		
		return null;
	}


	
	public String selecionar(Categoria categoria){
		this.categoria = categoria;
		tabCadastro.setInView(true);;
		return "/admin/categorrfrfia";
	}
	
	
	public String deletar(Categoria categoria){
		
		
		try{
			dao.delete(categoria);
			MensagemUTIL.addInfo("Registro deletado com sucesso");
		}finally{
			dao.close();  
		}
		
		return null;
	}
	
	
	//----------------------
	
	public Categoria getCategoria() {
		return categoria;
	}


	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}


	public Tab getTabCadastro() {
		return tabCadastro;
	}


	public void setTabCadastro(Tab tabCadastro) {
		this.tabCadastro = tabCadastro;
	}
		
}
