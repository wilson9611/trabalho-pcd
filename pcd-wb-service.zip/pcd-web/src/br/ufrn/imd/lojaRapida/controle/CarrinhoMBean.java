package br.ufrn.imd.lojaRapida.controle;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import org.primefaces.event.DragDropEvent;

import br.ufrn.imd.lojaRapida.dao.ClienteDAO;
import br.ufrn.imd.lojaRapida.dominio.Cliente;
import br.ufrn.imd.lojaRapida.dominio.Produto;

@ManagedBean
@SessionScoped
public class CarrinhoMBean {
	
	private List<Produto> itens = new ArrayList<Produto>();
	private Double valorTotal = 0.0;
	
	Cliente cliente = new Cliente();
	
	
	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public void adicionar(DragDropEvent ddEvent){
		Produto produto = ((Produto) ddEvent.getData());
		itens.add(produto);
		calcularTotal();
	}
	
	public String remover(Produto produto){
		itens.remove(produto);
		calcularTotal();
		return null;
	}
	
	private void calcularTotal(){
		valorTotal = 0.0;
		for (Produto produto : itens) {
			valorTotal = Double.sum(valorTotal, produto.getPreco());
		}
	}
	
	public String fecharCompra() {
		return "resumoCompra.xhtml";
	}
	
	public List<Produto> getItens() {
		return itens;
	}
	public void setItens(List<Produto> itens) {
		this.itens = itens;
	}
	public Double getValorTotal() {
		return valorTotal;
	}
	public void setValorTotal(Double valorTotal) {
		this.valorTotal = valorTotal;
	}
	
	public String finalizarCompra() {
		return null;
	}
	
	public Boolean validarCliente() {
		ClienteDAO dao = new ClienteDAO();
		List<Cliente> listaCliente = dao.findAll();
		for (Cliente cliente : listaCliente) {
			if ( cliente.getEmail().equals(this.cliente.getEmail()) &&	
					(cliente.getSenha().equals(this.cliente.getSenha()))) {
						return true;
			} 
		}
		return false;
		
	}
	
	
}
