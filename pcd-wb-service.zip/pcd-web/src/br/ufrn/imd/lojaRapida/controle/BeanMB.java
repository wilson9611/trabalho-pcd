package br.ufrn.imd.lojaRapida.controle;

import javax.faces.bean.ManagedBean;

@ManagedBean()
public class BeanMB{
   private Double valor;
   public Double getValor(){
	   return valor;
   }
   public void setValor(Double valor){
      this.valor = valor;
   }
   
   public String submete(){
	   this.valor = new Double("123");
	   
	   return null;
   }
}
